_RNvNtNtCscX113maW9sw_5rarog5board7movegen23generate_legal_movelist:
.seh_proc _RNvNtNtCscX113maW9sw_5rarog5board7movegen23generate_legal_movelist
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$712, %rsp
	.seh_stackalloc 712
	.seh_endprologue
	movq	%rdx, %rsi
	movq	%rcx, 184(%rsp)
	movq	$0, 704(%rsp)
	movzbl	258(%rdx), %ebx
	movl	%ebx, %eax
	shll	$4, %eax
	leal	(%rax,%rax,2), %eax
	movl	%ebx, %ebp
	xorb	$1, %bpl
	movl	$64, %edi
	movl	$64, %edx
	rep		bsfq	64(%rsi,%rax), %rdx
	movq	%rsi, %rcx
	movl	%ebx, %r8d
	movl	%ebp, %r9d
	callq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen14compute_pinned
	movq	%rax, 96(%rsp)
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB303_1
.LBB303_2:
	movq	120(%rsi,%rbx,8), %rcx
	movb	%bpl, 55(%rsp)
	movzbl	%bpl, %eax
	movq	%rax, 160(%rsp)
	movq	120(%rsi,%rax,8), %rbp
	movq	136(%rsi), %rax
	movq	%rax, 80(%rsp)
	movq	%rbx, 64(%rsp)
	shll	$4, %ebx
	leaq	(%rbx,%rbx,2), %rax
	movq	%rax, 120(%rsp)
	rep		bsfq	64(%rsi,%rax), %rdi
	movq	%rsi, 72(%rsp)
	movq	248(%rsi), %rax
	movq	%rax, 168(%rsp)
	movl	%edi, %r14d
	andl	$63, %r14d
	movl	%r14d, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rdx
	notq	%rcx
	movq	1584(%rdx,%rax,8), %rbx
	movq	%rcx, 176(%rsp)
	andq	%rcx, %rbx
	je	.LBB303_112
	movq	80(%rsp), %r13
	btcq	%r14, %r13
	movl	%edi, %r15d
	orl	$16384, %r15d
	movq	704(%rsp), %rsi
	jmp	.LBB303_4
.LBB303_6:
	movl	%edi, %eax
	cmpq	$256, %rsi
	jb	.LBB303_110
	jmp	.LBB303_8
	.p2align	4
.LBB303_4:
	rep		bsfq	%rbx, %r12
	movq	72(%rsp), %rcx
	movl	%r12d, %edx
	movzbl	55(%rsp), %r8d
	movq	%r13, %r9
	callq	_RNvMs0_NtNtCscX113maW9sw_5rarog5board7movegenNtNtB7_5board5Board20is_attacked_with_occ
	testb	%al, %al
	jne	.LBB303_111
	btq	%r12, %rbp
	jae	.LBB303_6
	movl	%r15d, %eax
	cmpq	$256, %rsi
	jae	.LBB303_8
.LBB303_110:
	shll	$6, %r12d
	movzwl	%ax, %eax
	orl	%r12d, %eax
	movw	%ax, 192(%rsp,%rsi,2)
	incq	%rsi
	movq	%rsi, 704(%rsp)
.LBB303_111:
	leaq	-1(%rbx), %rax
	andq	%rax, %rbx
	jne	.LBB303_4
.LBB303_112:
	movq	168(%rsp), %rcx
	leaq	-1(%rcx), %rax
	testq	%rax, %rcx
	jne	.LBB303_113
	testq	%rcx, %rcx
	je	.LBB303_10
	rep		bsfq	%rcx, %rax
	movl	%r14d, %ecx
	shll	$9, %ecx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen7BETWEEN(%rip), %rdx
	addq	%rcx, %rdx
	movq	(%rdx,%rax,8), %rcx
	btsq	%rax, %rcx
	movq	%rcx, 56(%rsp)
	jmp	.LBB303_12
.LBB303_10:
	movq	$-1, 56(%rsp)
.LBB303_12:
	movq	96(%rsp), %r12
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	movq	72(%rsp), %rsi
	movq	64(%rsp), %rdi
	jne	.LBB303_13
.LBB303_14:
	leaq	48(%rsi), %rax
	testb	%dil, %dil
	cmoveq	%rsi, %rax
	movq	24(%rax), %rsi
	notq	%r12
	movq	%rsi, 152(%rsp)
	andq	%r12, %rsi
	leaq	192(%rsp), %rax
	movq	%rax, 32(%rsp)
	movl	%edi, %ecx
	movq	%rsi, %rdx
	movq	80(%rsp), %r8
	movq	56(%rsp), %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen24gen_unpinned_pawn_quietsNtNtB4_5moves8MoveListEB6_
	testb	%dil, %dil
	movq	%r14, 88(%rsp)
	movq	%rsi, %rax
	je	.LBB303_16
	shrq	$7, %rax
	movabsq	$71775015237779198, %r15
	andq	%rax, %r15
	shrq	$9, %rsi
	movabsq	$35887507618889599, %rdi
	andq	%rsi, %rdi
	movb	$7, %bl
	movb	$9, %r13b
	andq	%rbp, %r15
	andq	56(%rsp), %r15
	jne	.LBB303_18
	jmp	.LBB303_20
.LBB303_16:
	shlq	$9, %rax
	movabsq	$-72340172838076928, %r15
	andq	%rax, %r15
	shlq	$7, %rsi
	movabsq	$9187201950435737344, %rdi
	andq	%rsi, %rdi
	movb	$-9, %bl
	movb	$-7, %r13b
	andq	%rbp, %r15
	andq	56(%rsp), %r15
	je	.LBB303_20
.LBB303_18:
	leaq	192(%rsp), %rsi
	.p2align	4
.LBB303_19:
	movq	%r15, %r14
	rep		bsfq	%r15, %rdx
	decq	%r15
	leal	(%rbx,%rdx), %ecx
	movb	$1, %r8b
	movq	%rsi, %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen20push_pawn_move_flagsNtNtB4_5moves8MoveListEB6_
	andq	%r14, %r15
	jne	.LBB303_19
.LBB303_20:
	movq	152(%rsp), %r15
	andq	96(%rsp), %r15
	andq	%rbp, %rdi
	andq	56(%rsp), %rdi
	je	.LBB303_23
	leaq	192(%rsp), %rsi
	.p2align	4
.LBB303_22:
	movq	%rdi, %rbx
	rep		bsfq	%rdi, %rdx
	decq	%rdi
	leal	(%r13,%rdx), %ecx
	movb	$1, %r8b
	movq	%rsi, %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen20push_pawn_move_flagsNtNtB4_5moves8MoveListEB6_
	andq	%rbx, %rdi
	jne	.LBB303_22
.LBB303_23:
	cmpb	$0, 64(%rsp)
	movabsq	$71776119061217280, %rax
	movl	$65280, %ecx
	cmovneq	%rax, %rcx
	movq	%rcx, 136(%rsp)
	testq	%r15, %r15
	je	.LBB303_42
	movq	80(%rsp), %r14
	notq	%r14
	movq	160(%rsp), %rax
	shll	$4, %eax
	addq	$-8, %rax
	movq	%rax, 128(%rsp)
	movl	$1, %edi
	movq	88(%rsp), %rcx
	shlq	%cl, %rdi
	movq	64(%rsp), %rax
	shll	$9, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rcx
	addq	%rcx, %rax
	addq	$48, %rax
	movq	%rax, 144(%rsp)
	jmp	.LBB303_26
	.p2align	4
.LBB303_25:
	leaq	-1(%r15), %rax
	andq	%rax, %r15
	je	.LBB303_42
.LBB303_26:
	rep		bsfq	%r15, %rsi
	movl	$1, %ebx
	movl	%esi, %ecx
	shlq	%cl, %rbx
	movq	%rbx, %rax
	shrq	$8, %rax
	movl	$256, %r13d
	shlq	%cl, %r13
	cmpb	$0, 64(%rsp)
	cmovneq	%rax, %r13
	andq	%r14, %r13
	je	.LBB303_33
	testq	%r13, 56(%rsp)
	je	.LBB303_28
	movq	128(%rsp), %rax
	leaq	(%rsi,%rax), %rdx
	movl	%esi, %eax
	shll	$9, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	addq	%rcx, %rax
	testq	%rdi, (%rax,%rdx,8)
	je	.LBB303_28
	movl	%esi, %ecx
	xorl	%r8d, %r8d
	leaq	192(%rsp), %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen20push_pawn_move_flagsNtNtB4_5moves8MoveListEB6_
.LBB303_28:
	testq	%rbx, 136(%rsp)
	je	.LBB303_33
	movq	%r13, %rax
	shrq	$8, %rax
	shlq	$8, %r13
	cmpb	$0, 64(%rsp)
	cmovneq	%rax, %r13
	andq	%r14, %r13
	andq	56(%rsp), %r13
	je	.LBB303_33
	rep		bsfq	%r13, %rax
	movl	%esi, %ecx
	shll	$9, %ecx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rdx
	addq	%rdx, %rcx
	testq	%rdi, (%rcx,%rax,8)
	je	.LBB303_33
	movq	704(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB303_102
	shll	$6, %eax
	movl	%esi, %edx
	orl	%eax, %edx
	orl	$4096, %edx
	movw	%dx, 192(%rsp,%rcx,2)
	incq	704(%rsp)
	.p2align	4
.LBB303_33:
	movq	144(%rsp), %rax
	movq	(%rax,%rsi,8), %rax
	andq	56(%rsp), %rax
	andq	%rbp, %rax
	je	.LBB303_25
	movl	%esi, %edx
	shll	$9, %edx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	addq	%rcx, %rdx
	leal	16384(%rsi), %ecx
	movzwl	%cx, %r8d
	movzwl	%si, %r9d
	jmp	.LBB303_35
	.p2align	4
.LBB303_41:
	orl	$49152, %r10d
.LBB303_62:
	movw	%r10w, 192(%rsp,%rcx,2)
	incq	704(%rsp)
.LBB303_63:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB303_25
.LBB303_35:
	rep		bsfq	%rax, %r10
	testq	%rdi, (%rdx,%r10,8)
	je	.LBB303_63
	movl	%r10d, %ecx
	shrb	$3, %cl
	decb	%cl
	cmpb	$6, %cl
	jae	.LBB303_37
	movq	704(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB303_102
	shll	$6, %r10d
	orl	%r8d, %r10d
	jmp	.LBB303_62
	.p2align	4
.LBB303_37:
	movq	704(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB303_102
	shll	$6, %r10d
	orl	%r9d, %r10d
	movzwl	%r10w, %r10d
	movl	%r10d, %r11d
	orl	$61440, %r11d
	movw	%r11w, 192(%rsp,%rcx,2)
	movq	704(%rsp), %r11
	leaq	1(%r11), %rcx
	movq	%rcx, 704(%rsp)
	cmpq	$256, %rcx
	jae	.LBB303_102
	leal	57344(%r10), %ecx
	movw	%cx, 194(%rsp,%r11,2)
	movq	704(%rsp), %r11
	leaq	1(%r11), %rcx
	movq	%rcx, 704(%rsp)
	cmpq	$256, %rcx
	jae	.LBB303_102
	movl	%r10d, %ecx
	orl	$53248, %ecx
	movw	%cx, 194(%rsp,%r11,2)
	movq	704(%rsp), %rcx
	incq	%rcx
	movq	%rcx, 704(%rsp)
	cmpq	$256, %rcx
	jb	.LBB303_41
.LBB303_102:
	leaq	anon.2af38a137a80de8a147d965b237c0766.20(%rip), %r8
	movl	$256, %edx
	callq	_RNvNtCs55qC6OcLGgs_4core9panicking18panic_bounds_check
	ud2
.LBB303_42:
	movq	72(%rsp), %rax
	movzbl	260(%rax), %edx
	cmpq	$255, %rdx
	movq	152(%rsp), %rbx
	je	.LBB303_55
	movq	64(%rsp), %r8
	shlb	$4, %r8b
	addb	%dl, %r8b
	addb	$-8, %r8b
	movl	%edx, %eax
	andl	$63, %eax
	movl	$1, %r9d
	movl	%eax, %ecx
	shlq	%cl, %r9
	movq	56(%rsp), %rcx
	btq	%rax, %rcx
	jb	.LBB303_45
	movzbl	%r8b, %ecx
	movq	56(%rsp), %r10
	btq	%rcx, %r10
	jae	.LBB303_55
.LBB303_45:
	movq	160(%rsp), %r10
	shll	$9, %r10d
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rcx
	addq	%rcx, %r10
	shll	$3, %eax
	andq	48(%rax,%r10), %rbx
	je	.LBB303_55
	movl	$1, %r10d
	movq	88(%rsp), %rcx
	shlq	%cl, %r10
	movq	%r10, 144(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %r11
	addq	%rax, %r11
	xorl	%eax, %eax
	cmpb	$0, 64(%rsp)
	movl	$11, %ecx
	movl	$5, %r14d
	cmovneq	%rcx, %r14
	movl	$6, %r15d
	cmovneq	%rax, %r15
	movzwl	%dx, %eax
	shll	$6, %eax
	movq	80(%rsp), %rdi
	btcq	%r8, %rdi
	xorq	%r9, %rdi
	movzwl	%ax, %eax
	movl	%eax, 136(%rsp)
	jmp	.LBB303_47
	.p2align	4
.LBB303_54:
	leaq	-1(%rbx), %rax
	andq	%rax, %rbx
	je	.LBB303_55
.LBB303_47:
	rep		bsfq	%rbx, %rsi
	movl	$1, %r13d
	movl	%esi, %ecx
	shlq	%cl, %r13
	movq	96(%rsp), %rax
	btq	%rsi, %rax
	jae	.LBB303_48
	movl	%esi, %eax
	shll	$9, %eax
	movq	144(%rsp), %rcx
	testq	%rcx, (%r11,%rax)
	je	.LBB303_54
.LBB303_48:
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB303_49
.LBB303_50:
	movl	$64, %eax
	movq	72(%rsp), %r9
	rep		bsfq	24(%r9,%r14,8), %rax
	xorq	%rdi, %r13
	movq	56(%r9,%r15,8), %rdx
	andl	$63, %eax
	shll	$5, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %r10
	movq	4144(%rax,%r10), %r8
	andq	%r13, %r8
	imulq	4160(%rax,%r10), %r8
	movzbl	4168(%rax,%r10), %ecx
	shrq	%cl, %r8
	addq	4152(%rax,%r10), %r8
	andq	2096(%rax,%r10), %r13
	movq	48(%r9,%r15,8), %r9
	imulq	2112(%rax,%r10), %r13
	movzbl	2120(%rax,%r10), %ecx
	shrq	%cl, %r13
	orq	%rdx, %r9
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %rcx
	testq	%r9, (%rcx,%r8,8)
	jne	.LBB303_54
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rcx
	addq	2104(%rax,%rcx), %r13
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rax
	movq	72(%rsp), %rcx
	orq	40(%rcx,%r15,8), %rdx
	testq	%rdx, (%rax,%r13,8)
	jne	.LBB303_54
	movq	704(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB303_102
	orl	136(%rsp), %esi
	orl	$20480, %esi
	movw	%si, 192(%rsp,%rcx,2)
	incq	704(%rsp)
	jmp	.LBB303_54
.LBB303_49:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rax
	movq	%rax, 104(%rsp)
	leaq	104(%rsp), %rax
	movq	%rax, 112(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	movb	$1, %dl
	leaq	112(%rsp), %r8
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	movq	%r11, 128(%rsp)
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	movq	128(%rsp), %r11
	jmp	.LBB303_50
.LBB303_55:
	movq	72(%rsp), %r14
	movq	120(%rsp), %rax
	andq	32(%r14,%rax), %r12
	movq	176(%rsp), %r13
	jne	.LBB303_65
.LBB303_56:
	movq	120(%rsp), %rax
	movq	40(%r14,%rax), %rax
	testq	%rax, %rax
	movq	96(%rsp), %r15
	movq	80(%rsp), %r12
	je	.LBB303_80
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rdx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	movq	88(%rsp), %r8
	leaq	(%rcx,%r8,8), %r8
	jmp	.LBB303_72
	.p2align	4
.LBB303_64:
	leaq	-1(%r12), %rax
	andq	%rax, %r12
	je	.LBB303_56
.LBB303_65:
	rep		bsfq	%r12, %rax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rcx
	movq	1072(%rcx,%rax,8), %rdx
	andq	%r13, %rdx
	andq	56(%rsp), %rdx
	je	.LBB303_64
	movzwl	%ax, %r8d
	orl	$16384, %r8d
	movq	704(%rsp), %rcx
	.p2align	4
.LBB303_67:
	rep		bsfq	%rdx, %r9
	btq	%r9, %rbp
	jae	.LBB303_68
	movl	%r8d, %r10d
	cmpq	$256, %rcx
	jb	.LBB303_70
	jmp	.LBB303_102
	.p2align	4
.LBB303_68:
	movl	%eax, %r10d
	cmpq	$256, %rcx
	jae	.LBB303_102
.LBB303_70:
	leaq	-1(%rdx), %r11
	andq	%r11, %rdx
	shll	$6, %r9d
	movzwl	%r10w, %r10d
	addl	%r9d, %r10d
	movw	%r10w, 192(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 704(%rsp)
	testq	%rdx, %rdx
	jne	.LBB303_67
	jmp	.LBB303_64
	.p2align	4
.LBB303_71:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB303_80
.LBB303_72:
	rep		bsfq	%rax, %r9
	movl	%r9d, %r10d
	shll	$5, %r10d
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rsi
	movq	2096(%r10,%rsi), %r11
	andq	%r12, %r11
	imulq	2112(%r10,%rsi), %r11
	movzbl	2120(%r10,%rsi), %ecx
	shrq	%cl, %r11
	addq	2104(%r10,%rsi), %r11
	movq	(%rdx,%r11,8), %r10
	andq	%r13, %r10
	andq	56(%rsp), %r10
	btq	%r9, %r15
	jae	.LBB303_74
	movl	%r9d, %ecx
	shll	$9, %ecx
	andq	(%r8,%rcx), %r10
.LBB303_74:
	testq	%r10, %r10
	je	.LBB303_71
	movzwl	%r9w, %r11d
	orl	$16384, %r11d
	movq	704(%rsp), %rcx
	.p2align	4
.LBB303_76:
	rep		bsfq	%r10, %rsi
	btq	%rsi, %rbp
	jae	.LBB303_77
	movl	%r11d, %edi
	cmpq	$256, %rcx
	jb	.LBB303_79
	jmp	.LBB303_102
	.p2align	4
.LBB303_77:
	movl	%r9d, %edi
	cmpq	$256, %rcx
	jae	.LBB303_102
.LBB303_79:
	leaq	-1(%r10), %rbx
	andq	%rbx, %r10
	shll	$6, %esi
	movzwl	%di, %edi
	addl	%esi, %edi
	movw	%di, 192(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 704(%rsp)
	testq	%r10, %r10
	jne	.LBB303_76
	jmp	.LBB303_71
.LBB303_80:
	movq	120(%rsp), %rax
	movq	48(%r14,%rax), %rax
	testq	%rax, %rax
	je	.LBB303_91
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %rdx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	movq	88(%rsp), %r8
	leaq	(%rcx,%r8,8), %r8
	jmp	.LBB303_83
	.p2align	4
.LBB303_82:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB303_91
.LBB303_83:
	rep		bsfq	%rax, %r9
	movl	%r9d, %r10d
	shll	$5, %r10d
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rsi
	movq	4144(%r10,%rsi), %r11
	andq	%r12, %r11
	imulq	4160(%r10,%rsi), %r11
	movzbl	4168(%r10,%rsi), %ecx
	shrq	%cl, %r11
	addq	4152(%r10,%rsi), %r11
	movq	(%rdx,%r11,8), %r10
	andq	%r13, %r10
	andq	56(%rsp), %r10
	btq	%r9, %r15
	jae	.LBB303_85
	movl	%r9d, %ecx
	shll	$9, %ecx
	andq	(%r8,%rcx), %r10
.LBB303_85:
	testq	%r10, %r10
	je	.LBB303_82
	movzwl	%r9w, %r11d
	orl	$16384, %r11d
	movq	704(%rsp), %rcx
	.p2align	4
.LBB303_87:
	rep		bsfq	%r10, %rsi
	btq	%rsi, %rbp
	jae	.LBB303_88
	movl	%r11d, %edi
	cmpq	$256, %rcx
	jb	.LBB303_90
	jmp	.LBB303_102
	.p2align	4
.LBB303_88:
	movl	%r9d, %edi
	cmpq	$256, %rcx
	jae	.LBB303_102
.LBB303_90:
	leaq	-1(%r10), %rbx
	andq	%rbx, %r10
	shll	$6, %esi
	movzwl	%di, %edi
	addl	%esi, %edi
	movw	%di, 192(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 704(%rsp)
	testq	%r10, %r10
	jne	.LBB303_87
	jmp	.LBB303_82
.LBB303_91:
	movq	120(%rsp), %rax
	movq	56(%r14,%rax), %rax
	testq	%rax, %rax
	je	.LBB303_103
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rdx
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %r8
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	movq	88(%rsp), %r9
	leaq	(%rcx,%r9,8), %r9
	andq	56(%rsp), %r13
	jmp	.LBB303_95
	.p2align	4
.LBB303_94:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB303_103
.LBB303_95:
	rep		bsfq	%rax, %r10
	movl	%r10d, %r11d
	shll	$5, %r11d
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rbx
	movq	2096(%r11,%rbx), %rsi
	andq	%r12, %rsi
	imulq	2112(%r11,%rbx), %rsi
	movzbl	2120(%r11,%rbx), %ecx
	shrq	%cl, %rsi
	addq	2104(%r11,%rbx), %rsi
	movq	4144(%r11,%rbx), %rdi
	andq	%r12, %rdi
	imulq	4160(%r11,%rbx), %rdi
	movzbl	4168(%r11,%rbx), %ecx
	shrq	%cl, %rdi
	addq	4152(%r11,%rbx), %rdi
	movq	(%r8,%rdi,8), %r11
	orq	(%rdx,%rsi,8), %r11
	andq	%r13, %r11
	btq	%r10, %r15
	jae	.LBB303_97
	movl	%r10d, %ecx
	shll	$9, %ecx
	andq	(%r9,%rcx), %r11
.LBB303_97:
	testq	%r11, %r11
	je	.LBB303_94
	movzwl	%r10w, %esi
	orl	$16384, %esi
	movq	704(%rsp), %rcx
	.p2align	4
.LBB303_99:
	rep		bsfq	%r11, %rdi
	btq	%rdi, %rbp
	jae	.LBB303_100
	movl	%esi, %ebx
	cmpq	$256, %rcx
	jb	.LBB303_93
	jmp	.LBB303_102
	.p2align	4
.LBB303_100:
	movl	%r10d, %ebx
	cmpq	$256, %rcx
	jae	.LBB303_102
.LBB303_93:
	leaq	-1(%r11), %r14
	andq	%r14, %r11
	shll	$6, %edi
	movzwl	%bx, %ebx
	addl	%edi, %ebx
	movw	%bx, 192(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 704(%rsp)
	testq	%r11, %r11
	jne	.LBB303_99
	jmp	.LBB303_94
.LBB303_103:
	cmpq	$0, 168(%rsp)
	jne	.LBB303_113
	leaq	192(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	72(%rsp), %rcx
	movq	64(%rsp), %rdx
	movzbl	55(%rsp), %r8d
	movq	80(%rsp), %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen12gen_castlingNtNtB4_5moves8MoveListEB6_
.LBB303_113:
	leaq	192(%rsp), %rdx
	movl	$520, %r8d
	movq	184(%rsp), %rsi
	movq	%rsi, %rcx
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$712, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB303_1:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rax
	movq	%rax, 104(%rsp)
	leaq	104(%rsp), %rax
	movq	%rax, 112(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	leaq	112(%rsp), %r8
	movb	$1, %dl
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	jmp	.LBB303_2
.LBB303_13:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rax
	movq	%rax, 104(%rsp)
	leaq	104(%rsp), %rax
	movq	%rax, 112(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	leaq	112(%rsp), %r8
	movb	$1, %dl
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	jmp	.LBB303_14
.LBB303_8:
	leaq	anon.2af38a137a80de8a147d965b237c0766.20(%rip), %r8
	movl	$256, %edx
	movq	%rsi, %rcx
	callq	_RNvNtCs55qC6OcLGgs_4core9panicking18panic_bounds_check
	ud2
	.seh_endproc
