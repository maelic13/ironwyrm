_RNvNtNtCscX113maW9sw_5rarog5board7movegen23generate_legal_movelist:
.seh_proc _RNvNtNtCscX113maW9sw_5rarog5board7movegen23generate_legal_movelist
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$728, %rsp
	.seh_stackalloc 728
	.seh_endprologue
	movq	%rdx, %r15
	movq	%rcx, 176(%rsp)
	movzbl	258(%rdx), %edi
	movl	%edi, %eax
	shll	$4, %eax
	leal	(%rax,%rax,2), %eax
	movl	$64, %esi
	rep		bsfq	64(%rdx,%rax), %rsi
	movq	$0, 720(%rsp)
	movq	120(%rdx,%rdi,8), %r12
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB302_1
.LBB302_2:
	xorl	%ebx, %ebx
	testb	%dil, %dil
	movl	$48, %eax
	cmovnel	%ebx, %eax
	movq	56(%r15,%rax), %r8
	movq	40(%r15,%rax), %r9
	orq	%r8, %r9
	andl	$63, %esi
	orq	48(%r15,%rax), %r8
	movl	%esi, %eax
	shll	$5, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %r13
	movq	2104(%rax,%r13), %rcx
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rdx
	movq	(%rdx,%rcx,8), %rcx
	movq	%r9, 184(%rsp)
	andq	%r9, %rcx
	movq	4152(%rax,%r13), %rax
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %rdx
	movq	(%rdx,%rax,8), %rax
	movq	%r8, 200(%rsp)
	andq	%r8, %rax
	orq	%rcx, %rax
	je	.LBB302_5
	shll	$9, %esi
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen7BETWEEN(%rip), %rcx
	addq	%rsi, %rcx
	movq	136(%r15), %rdx
	xorl	%r8d, %r8d
	xorl	%ebx, %ebx
	.p2align	4
.LBB302_4:
	movq	%rax, %r9
	decq	%rax
	rep		bsfq	%r9, %r10
	movq	(%rcx,%r10,8), %r10
	andq	%rdx, %r10
	leaq	-1(%r10), %r11
	movq	%r10, %rsi
	andq	%r12, %rsi
	testq	%r11, %r10
	cmovneq	%r8, %rsi
	orq	%rsi, %rbx
	andq	%r9, %rax
	jne	.LBB302_4
.LBB302_5:
	movl	%edi, %r8d
	xorb	$1, %r8b
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB302_6
.LBB302_7:
	movzbl	%r8b, %eax
	movq	%rax, 152(%rsp)
	movq	120(%r15,%rax,8), %r14
	movq	136(%r15), %rax
	movq	%rax, 72(%rsp)
	movq	248(%r15), %rax
	movq	%rax, 160(%rsp)
	movq	%rdi, 64(%rsp)
	movl	%edi, %eax
	shll	$4, %eax
	leaq	(%rax,%rax,2), %rax
	movl	$64, %ecx
	movq	%r15, 112(%rsp)
	movq	%rax, 128(%rsp)
	rep		bsfq	64(%r15,%rax), %rcx
	movq	%rcx, 48(%rsp)
	andl	$63, %ecx
	movq	%rcx, 80(%rsp)
	movl	%ecx, %eax
	notq	%r12
	movq	1584(%r13,%rax,8), %r15
	movq	%r12, 168(%rsp)
	andq	%r12, %r15
	je	.LBB302_118
	movq	72(%rsp), %r12
	movq	80(%rsp), %rax
	btcq	%rax, %r12
	movq	48(%rsp), %rax
	movl	%eax, %ebp
	orl	$16384, %ebp
	movq	720(%rsp), %rsi
	jmp	.LBB302_9
	.p2align	4
.LBB302_10:
	movl	%edi, %r8d
	leaq	-1(%r15), %rax
	andq	%rax, %r15
	je	.LBB302_118
.LBB302_9:
	rep		bsfq	%r15, %r13
	movq	112(%rsp), %rcx
	movl	%r13d, %edx
	movl	%r8d, %edi
	movq	%r12, %r9
	callq	_RNvMs0_NtNtCscX113maW9sw_5rarog5board7movegenNtNtB7_5board5Board20is_attacked_with_occ
	testb	%al, %al
	jne	.LBB302_10
	btq	%r13, %r14
	jae	.LBB302_112
	movl	%ebp, %eax
	cmpq	$256, %rsi
	movl	%edi, %r8d
	jb	.LBB302_116
	jmp	.LBB302_114
.LBB302_112:
	movq	48(%rsp), %rax
	cmpq	$256, %rsi
	movl	%edi, %r8d
	jae	.LBB302_114
.LBB302_116:
	shll	$6, %r13d
	movzwl	%ax, %eax
	orl	%r13d, %eax
	movw	%ax, 208(%rsp,%rsi,2)
	incq	%rsi
	movq	%rsi, 720(%rsp)
	leaq	-1(%r15), %rax
	andq	%rax, %r15
	jne	.LBB302_9
.LBB302_118:
	movq	160(%rsp), %rcx
	leaq	-1(%rcx), %rax
	testq	%rax, %rcx
	jne	.LBB302_119
	testq	%rcx, %rcx
	movb	%r8b, 63(%rsp)
	je	.LBB302_12
	rep		bsfq	%rcx, %rax
	movq	80(%rsp), %rcx
	shll	$9, %ecx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen7BETWEEN(%rip), %rdx
	addq	%rcx, %rdx
	movq	(%rdx,%rax,8), %rcx
	btsq	%rax, %rcx
	movq	%rcx, 48(%rsp)
	jmp	.LBB302_14
.LBB302_12:
	movq	$-1, 48(%rsp)
.LBB302_14:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rcx
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	movq	112(%rsp), %rsi
	movq	64(%rsp), %r15
	jne	.LBB302_15
.LBB302_16:
	leaq	48(%rsi), %rax
	testb	%r15b, %r15b
	cmoveq	%rsi, %rax
	movq	24(%rax), %rsi
	movq	%rbx, %rdi
	notq	%rdi
	movq	%rsi, 120(%rsp)
	andq	%rdi, %rsi
	leaq	208(%rsp), %rax
	movq	%rax, 32(%rsp)
	movl	%r15d, %ecx
	movq	%rsi, %rdx
	movq	72(%rsp), %r8
	movq	48(%rsp), %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen24gen_unpinned_pawn_quietsNtNtB4_5moves8MoveListEB6_
	movq	%rsi, %rax
	testb	%r15b, %r15b
	je	.LBB302_18
	shrq	$7, %rax
	movabsq	$71775015237779198, %r15
	andq	%rax, %r15
	shrq	$9, %rsi
	movabsq	$35887507618889599, %r13
	andq	%rsi, %r13
	movb	$7, %bpl
	movb	$9, %al
	movq	%rax, 88(%rsp)
	andq	%r14, %r15
	andq	48(%rsp), %r15
	jne	.LBB302_20
	jmp	.LBB302_22
.LBB302_18:
	shlq	$9, %rax
	movabsq	$-72340172838076928, %r15
	andq	%rax, %r15
	shlq	$7, %rsi
	movabsq	$9187201950435737344, %r13
	andq	%rsi, %r13
	movb	$-9, %bpl
	movb	$-7, %al
	movq	%rax, 88(%rsp)
	andq	%r14, %r15
	andq	48(%rsp), %r15
	je	.LBB302_22
.LBB302_20:
	leaq	208(%rsp), %rsi
	.p2align	4
.LBB302_21:
	movq	%r15, %r12
	rep		bsfq	%r15, %rdx
	decq	%r15
	leal	(%rbp,%rdx), %ecx
	movb	$1, %r8b
	movq	%rsi, %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen20push_pawn_move_flagsNtNtB4_5moves8MoveListEB6_
	andq	%r12, %r15
	jne	.LBB302_21
.LBB302_22:
	movq	120(%rsp), %r15
	andq	%rbx, %r15
	andq	%r14, %r13
	andq	48(%rsp), %r13
	movq	88(%rsp), %rbp
	je	.LBB302_25
	leaq	208(%rsp), %rsi
	.p2align	4
.LBB302_24:
	movq	%r13, %r12
	rep		bsfq	%r13, %rdx
	decq	%r13
	leal	(%rbp,%rdx), %ecx
	movb	$1, %r8b
	movq	%rsi, %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen20push_pawn_move_flagsNtNtB4_5moves8MoveListEB6_
	andq	%r12, %r13
	jne	.LBB302_24
.LBB302_25:
	cmpb	$0, 64(%rsp)
	movabsq	$71776119061217280, %rax
	movl	$65280, %ecx
	cmovneq	%rax, %rcx
	movq	%rcx, 136(%rsp)
	testq	%r15, %r15
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rbp
	je	.LBB302_44
	movq	72(%rsp), %rax
	notq	%rax
	movq	%rax, 88(%rsp)
	movq	152(%rsp), %rax
	shll	$4, %eax
	addq	$-8, %rax
	movq	%rax, 192(%rsp)
	movl	$1, %r13d
	movq	80(%rsp), %rcx
	shlq	%cl, %r13
	movq	64(%rsp), %rax
	shll	$9, %eax
	addq	%rbp, %rax
	addq	$48, %rax
	movq	%rax, 144(%rsp)
	jmp	.LBB302_28
	.p2align	4
.LBB302_27:
	leaq	-1(%r15), %rax
	andq	%rax, %r15
	je	.LBB302_44
.LBB302_28:
	rep		bsfq	%r15, %rsi
	movl	$1, %ebp
	movl	%esi, %ecx
	shlq	%cl, %rbp
	movq	%rbp, %rax
	shrq	$8, %rax
	movl	$256, %r12d
	shlq	%cl, %r12
	cmpb	$0, 64(%rsp)
	cmovneq	%rax, %r12
	andq	88(%rsp), %r12
	je	.LBB302_35
	testq	%r12, 48(%rsp)
	je	.LBB302_30
	movq	192(%rsp), %rax
	leaq	(%rsi,%rax), %rdx
	movl	%esi, %eax
	shll	$9, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	addq	%rcx, %rax
	testq	%r13, (%rax,%rdx,8)
	je	.LBB302_30
	movl	%esi, %ecx
	xorl	%r8d, %r8d
	leaq	208(%rsp), %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen20push_pawn_move_flagsNtNtB4_5moves8MoveListEB6_
.LBB302_30:
	testq	%rbp, 136(%rsp)
	je	.LBB302_35
	movq	%r12, %rax
	shrq	$8, %rax
	shlq	$8, %r12
	cmpb	$0, 64(%rsp)
	cmovneq	%rax, %r12
	andq	88(%rsp), %r12
	andq	48(%rsp), %r12
	je	.LBB302_35
	rep		bsfq	%r12, %rax
	movl	%esi, %ecx
	shll	$9, %ecx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rdx
	addq	%rdx, %rcx
	testq	%r13, (%rcx,%rax,8)
	je	.LBB302_35
	movq	720(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB302_104
	shll	$6, %eax
	movl	%esi, %edx
	orl	%eax, %edx
	orl	$4096, %edx
	movw	%dx, 208(%rsp,%rcx,2)
	incq	720(%rsp)
	.p2align	4
.LBB302_35:
	movq	144(%rsp), %rax
	movq	(%rax,%rsi,8), %rax
	andq	48(%rsp), %rax
	andq	%r14, %rax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rbp
	je	.LBB302_27
	movl	%esi, %edx
	shll	$9, %edx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	addq	%rcx, %rdx
	leal	16384(%rsi), %ecx
	movzwl	%cx, %r8d
	movzwl	%si, %r9d
	jmp	.LBB302_37
	.p2align	4
.LBB302_43:
	orl	$49152, %r10d
.LBB302_64:
	movw	%r10w, 208(%rsp,%rcx,2)
	incq	720(%rsp)
.LBB302_65:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB302_27
.LBB302_37:
	rep		bsfq	%rax, %r10
	testq	%r13, (%rdx,%r10,8)
	je	.LBB302_65
	movl	%r10d, %ecx
	shrb	$3, %cl
	decb	%cl
	cmpb	$6, %cl
	jae	.LBB302_39
	movq	720(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB302_104
	shll	$6, %r10d
	orl	%r8d, %r10d
	jmp	.LBB302_64
	.p2align	4
.LBB302_39:
	movq	720(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB302_104
	shll	$6, %r10d
	orl	%r9d, %r10d
	movzwl	%r10w, %r10d
	movl	%r10d, %r11d
	orl	$61440, %r11d
	movw	%r11w, 208(%rsp,%rcx,2)
	movq	720(%rsp), %r11
	leaq	1(%r11), %rcx
	movq	%rcx, 720(%rsp)
	cmpq	$256, %rcx
	jae	.LBB302_104
	leal	57344(%r10), %ecx
	movw	%cx, 210(%rsp,%r11,2)
	movq	720(%rsp), %r11
	leaq	1(%r11), %rcx
	movq	%rcx, 720(%rsp)
	cmpq	$256, %rcx
	jae	.LBB302_104
	movl	%r10d, %ecx
	orl	$53248, %ecx
	movw	%cx, 210(%rsp,%r11,2)
	movq	720(%rsp), %rcx
	incq	%rcx
	movq	%rcx, 720(%rsp)
	cmpq	$256, %rcx
	jb	.LBB302_43
.LBB302_104:
	leaq	anon.2af38a137a80de8a147d965b237c0766.20(%rip), %r8
	movl	$256, %edx
	callq	_RNvNtCs55qC6OcLGgs_4core9panicking18panic_bounds_check
	ud2
.LBB302_44:
	movq	112(%rsp), %rax
	movzbl	260(%rax), %eax
	cmpq	$255, %rax
	movq	120(%rsp), %r11
	je	.LBB302_57
	movq	64(%rsp), %rdx
	shlb	$4, %dl
	addb	%al, %dl
	addb	$-8, %dl
	movl	%eax, %ecx
	andl	$63, %ecx
	movl	$1, %r8d
	shlq	%cl, %r8
	movq	48(%rsp), %r9
	btq	%rcx, %r9
	jb	.LBB302_47
	movzbl	%dl, %r9d
	movq	48(%rsp), %r10
	btq	%r9, %r10
	jae	.LBB302_57
.LBB302_47:
	movq	152(%rsp), %r9
	shll	$9, %r9d
	addq	%rbp, %r9
	shll	$3, %ecx
	andq	48(%rcx,%r9), %r11
	je	.LBB302_57
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %r9
	addq	%rcx, %r9
	movl	$1, %r10d
	movq	80(%rsp), %rcx
	shlq	%cl, %r10
	cmpb	$0, 64(%rsp)
	movl	$11, %ecx
	movl	$5, %r15d
	cmovneq	%rcx, %r15
	movzwl	%ax, %eax
	shll	$6, %eax
	movq	72(%rsp), %rsi
	btcq	%rdx, %rsi
	xorq	%r8, %rsi
	movzwl	%ax, %eax
	movl	%eax, 88(%rsp)
	jmp	.LBB302_49
	.p2align	4
.LBB302_56:
	leaq	-1(%r11), %rax
	andq	%rax, %r11
	je	.LBB302_57
.LBB302_49:
	rep		bsfq	%r11, %r13
	movl	$1, %r12d
	movl	%r13d, %ecx
	shlq	%cl, %r12
	btq	%r13, %rbx
	jae	.LBB302_50
	movl	%r13d, %eax
	shll	$9, %eax
	testq	%r10, (%r9,%rax)
	je	.LBB302_56
.LBB302_50:
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB302_51
.LBB302_52:
	movl	$64, %eax
	movq	112(%rsp), %rcx
	rep		bsfq	24(%rcx,%r15,8), %rax
	xorq	%rsi, %r12
	andl	$63, %eax
	shll	$5, %eax
	movq	4144(%rax,%rbp), %rdx
	andq	%r12, %rdx
	imulq	4160(%rax,%rbp), %rdx
	movzbl	4168(%rax,%rbp), %ecx
	shrq	%cl, %rdx
	addq	4152(%rax,%rbp), %rdx
	andq	2096(%rax,%rbp), %r12
	imulq	2112(%rax,%rbp), %r12
	movzbl	2120(%rax,%rbp), %ecx
	shrq	%cl, %r12
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %rcx
	movq	200(%rsp), %r8
	testq	%r8, (%rcx,%rdx,8)
	jne	.LBB302_56
	addq	2104(%rax,%rbp), %r12
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rax
	movq	184(%rsp), %rcx
	testq	%rcx, (%rax,%r12,8)
	jne	.LBB302_56
	movq	720(%rsp), %rcx
	cmpq	$256, %rcx
	jae	.LBB302_104
	orl	88(%rsp), %r13d
	orl	$20480, %r13d
	movw	%r13w, 208(%rsp,%rcx,2)
	incq	720(%rsp)
	jmp	.LBB302_56
.LBB302_51:
	movq	%rbp, 96(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	movb	$1, %dl
	leaq	104(%rsp), %r8
	movq	%r9, 144(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	movq	%r11, 120(%rsp)
	movq	%r10, 136(%rsp)
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	movq	136(%rsp), %r10
	movq	144(%rsp), %r9
	movq	120(%rsp), %r11
	jmp	.LBB302_52
.LBB302_57:
	movq	112(%rsp), %r12
	movq	128(%rsp), %rax
	andq	32(%r12,%rax), %rdi
	movq	168(%rsp), %r13
	jne	.LBB302_67
.LBB302_58:
	movq	128(%rsp), %rax
	movq	40(%r12,%rax), %rax
	testq	%rax, %rax
	je	.LBB302_82
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rdx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	movq	80(%rsp), %r8
	leaq	(%rcx,%r8,8), %r8
	jmp	.LBB302_74
	.p2align	4
.LBB302_66:
	leaq	-1(%rdi), %rax
	andq	%rax, %rdi
	je	.LBB302_58
.LBB302_67:
	rep		bsfq	%rdi, %rax
	movq	1072(%rbp,%rax,8), %rdx
	andq	%r13, %rdx
	andq	48(%rsp), %rdx
	je	.LBB302_66
	movzwl	%ax, %r8d
	orl	$16384, %r8d
	movq	720(%rsp), %rcx
	.p2align	4
.LBB302_69:
	rep		bsfq	%rdx, %r9
	btq	%r9, %r14
	jae	.LBB302_70
	movl	%r8d, %r10d
	cmpq	$256, %rcx
	jb	.LBB302_72
	jmp	.LBB302_104
	.p2align	4
.LBB302_70:
	movl	%eax, %r10d
	cmpq	$256, %rcx
	jae	.LBB302_104
.LBB302_72:
	leaq	-1(%rdx), %r11
	andq	%r11, %rdx
	shll	$6, %r9d
	movzwl	%r10w, %r10d
	addl	%r9d, %r10d
	movw	%r10w, 208(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 720(%rsp)
	testq	%rdx, %rdx
	jne	.LBB302_69
	jmp	.LBB302_66
	.p2align	4
.LBB302_73:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB302_82
.LBB302_74:
	rep		bsfq	%rax, %r9
	movl	%r9d, %r10d
	shll	$5, %r10d
	movq	2096(%r10,%rbp), %r11
	andq	72(%rsp), %r11
	imulq	2112(%r10,%rbp), %r11
	movzbl	2120(%r10,%rbp), %ecx
	shrq	%cl, %r11
	addq	2104(%r10,%rbp), %r11
	movq	(%rdx,%r11,8), %r10
	andq	%r13, %r10
	andq	48(%rsp), %r10
	btq	%r9, %rbx
	jae	.LBB302_76
	movl	%r9d, %ecx
	shll	$9, %ecx
	andq	(%r8,%rcx), %r10
.LBB302_76:
	testq	%r10, %r10
	je	.LBB302_73
	movzwl	%r9w, %r11d
	orl	$16384, %r11d
	movq	720(%rsp), %rcx
	.p2align	4
.LBB302_78:
	rep		bsfq	%r10, %rsi
	btq	%rsi, %r14
	jae	.LBB302_79
	movl	%r11d, %edi
	cmpq	$256, %rcx
	jb	.LBB302_81
	jmp	.LBB302_104
	.p2align	4
.LBB302_79:
	movl	%r9d, %edi
	cmpq	$256, %rcx
	jae	.LBB302_104
.LBB302_81:
	leaq	-1(%r10), %r15
	andq	%r15, %r10
	shll	$6, %esi
	movzwl	%di, %edi
	addl	%esi, %edi
	movw	%di, 208(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 720(%rsp)
	testq	%r10, %r10
	jne	.LBB302_78
	jmp	.LBB302_73
.LBB302_82:
	movq	128(%rsp), %rax
	movq	48(%r12,%rax), %rax
	testq	%rax, %rax
	je	.LBB302_93
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %rdx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	movq	80(%rsp), %r8
	leaq	(%rcx,%r8,8), %r8
	jmp	.LBB302_85
	.p2align	4
.LBB302_84:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	je	.LBB302_93
.LBB302_85:
	rep		bsfq	%rax, %r9
	movl	%r9d, %r10d
	shll	$5, %r10d
	movq	4144(%r10,%rbp), %r11
	andq	72(%rsp), %r11
	imulq	4160(%r10,%rbp), %r11
	movzbl	4168(%r10,%rbp), %ecx
	shrq	%cl, %r11
	addq	4152(%r10,%rbp), %r11
	movq	(%rdx,%r11,8), %r10
	andq	%r13, %r10
	andq	48(%rsp), %r10
	btq	%r9, %rbx
	jae	.LBB302_87
	movl	%r9d, %ecx
	shll	$9, %ecx
	andq	(%r8,%rcx), %r10
.LBB302_87:
	testq	%r10, %r10
	je	.LBB302_84
	movzwl	%r9w, %r11d
	orl	$16384, %r11d
	movq	720(%rsp), %rcx
	.p2align	4
.LBB302_89:
	rep		bsfq	%r10, %rsi
	btq	%rsi, %r14
	jae	.LBB302_90
	movl	%r11d, %edi
	cmpq	$256, %rcx
	jb	.LBB302_92
	jmp	.LBB302_104
	.p2align	4
.LBB302_90:
	movl	%r9d, %edi
	cmpq	$256, %rcx
	jae	.LBB302_104
.LBB302_92:
	leaq	-1(%r10), %r15
	andq	%r15, %r10
	shll	$6, %esi
	movzwl	%di, %edi
	addl	%esi, %edi
	movw	%di, 208(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 720(%rsp)
	testq	%r10, %r10
	jne	.LBB302_89
	jmp	.LBB302_84
.LBB302_93:
	movq	128(%rsp), %rax
	movq	56(%r12,%rax), %rax
	testq	%rax, %rax
	je	.LBB302_105
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %rdx
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %r8
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen4LINE(%rip), %rcx
	movq	80(%rsp), %r9
	leaq	(%rcx,%r9,8), %r9
	andq	48(%rsp), %r13
	jmp	.LBB302_97
	.p2align	4
.LBB302_96:
	leaq	-1(%rax), %rcx
	andq	%rcx, %rax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rbp
	je	.LBB302_105
.LBB302_97:
	rep		bsfq	%rax, %r10
	movl	%r10d, %r11d
	shll	$5, %r11d
	movq	2096(%r11,%rbp), %rsi
	movq	72(%rsp), %r15
	andq	%r15, %rsi
	imulq	2112(%r11,%rbp), %rsi
	movzbl	2120(%r11,%rbp), %ecx
	shrq	%cl, %rsi
	addq	2104(%r11,%rbp), %rsi
	movq	4144(%r11,%rbp), %rdi
	andq	%r15, %rdi
	imulq	4160(%r11,%rbp), %rdi
	movzbl	4168(%r11,%rbp), %ecx
	shrq	%cl, %rdi
	addq	4152(%r11,%rbp), %rdi
	movq	(%r8,%rdi,8), %r11
	orq	(%rdx,%rsi,8), %r11
	andq	%r13, %r11
	btq	%r10, %rbx
	jae	.LBB302_99
	movl	%r10d, %ecx
	shll	$9, %ecx
	andq	(%r9,%rcx), %r11
.LBB302_99:
	testq	%r11, %r11
	je	.LBB302_96
	movzwl	%r10w, %esi
	orl	$16384, %esi
	movq	720(%rsp), %rcx
	.p2align	4
.LBB302_101:
	rep		bsfq	%r11, %rdi
	btq	%rdi, %r14
	jae	.LBB302_102
	movl	%esi, %ebp
	cmpq	$256, %rcx
	jb	.LBB302_95
	jmp	.LBB302_104
	.p2align	4
.LBB302_102:
	movl	%r10d, %ebp
	cmpq	$256, %rcx
	jae	.LBB302_104
.LBB302_95:
	leaq	-1(%r11), %r15
	andq	%r15, %r11
	shll	$6, %edi
	movzwl	%bp, %ebp
	addl	%edi, %ebp
	movw	%bp, 208(%rsp,%rcx,2)
	incq	%rcx
	movq	%rcx, 720(%rsp)
	testq	%r11, %r11
	jne	.LBB302_101
	jmp	.LBB302_96
.LBB302_105:
	cmpq	$0, 160(%rsp)
	movzbl	63(%rsp), %r8d
	jne	.LBB302_119
	leaq	208(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	112(%rsp), %rcx
	movq	64(%rsp), %rdx
	movq	72(%rsp), %r9
	callq	_RINvNtNtCscX113maW9sw_5rarog5board7movegen12gen_castlingNtNtB4_5moves8MoveListEB6_
.LBB302_119:
	leaq	208(%rsp), %rdx
	movl	$520, %r8d
	movq	176(%rsp), %rsi
	movq	%rsi, %rcx
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$728, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB302_1:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rax
	movq	%rax, 96(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	leaq	104(%rsp), %r8
	movb	$1, %dl
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	jmp	.LBB302_2
.LBB302_6:
	movq	%r13, 96(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	movl	%r8d, %esi
	leaq	104(%rsp), %r8
	movb	$1, %dl
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	movl	%esi, %r8d
	jmp	.LBB302_7
.LBB302_15:
	movq	%rcx, 96(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %r9
	leaq	104(%rsp), %r8
	movb	$1, %dl
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	jmp	.LBB302_16
.LBB302_114:
	leaq	anon.2af38a137a80de8a147d965b237c0766.20(%rip), %r8
	movl	$256, %edx
	movq	%rsi, %rcx
	callq	_RNvNtCs55qC6OcLGgs_4core9panicking18panic_bounds_check
	ud2
	.seh_endproc
