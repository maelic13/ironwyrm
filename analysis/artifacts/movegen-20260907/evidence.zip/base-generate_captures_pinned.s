_RNvNtNtCscX113maW9sw_5rarog5board7movegen24generate_captures_pinned:
.seh_proc _RNvNtNtCscX113maW9sw_5rarog5board7movegen24generate_captures_pinned
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$576, %rsp
	.seh_stackalloc 576
	.seh_endprologue
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	$0, 568(%rsp)
	movzbl	258(%rdx), %ebx
	movl	%ebx, %ebp
	xorb	$1, %bpl
	movl	%ebx, %eax
	shll	$4, %eax
	leal	(%rax,%rax,2), %eax
	movl	$64, %r14d
	rep		bsfq	64(%rdx,%rax), %r14
	movq	%rdx, %rcx
	movl	%r14d, %edx
	movl	%ebx, %r8d
	movl	%ebp, %r9d
	callq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen14compute_pinned
	movq	%rax, %r15
	leaq	56(%rsp), %r12
	movq	%r12, 40(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rdi, %rcx
	movl	%ebx, %edx
	movl	%ebp, %r8d
	movl	%r14d, %r9d
	callq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen21gen_captures_with_pin
	movl	$520, %r8d
	movq	%rsi, %rcx
	movq	%r12, %rdx
	callq	memcpy
	movq	%r15, 520(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$576, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc
