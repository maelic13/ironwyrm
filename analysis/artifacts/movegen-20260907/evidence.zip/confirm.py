"""4.11b.8 fixed protocol; run from repo root after preparing hashed binaries."""
import ctypes, json, random, statistics, subprocess, sys
from pathlib import Path
sys.path.insert(0,str(Path('tools/diag').resolve()))
import board_search_profile as bp
import bench_counters as bc
out=Path('tools/results/movegen-411b8')
original_parse=bp.parse_search
def parse(lines,case,require_diag):
 d=original_parse(lines,case,require_diag)
 info=[l for l in lines if l.startswith('info ') and ' nodes ' in l][-1]
 best=[l for l in lines if l.startswith('bestmove ')][-1]
 d['pv']=info.split(' pv ',1)[1] if ' pv ' in info else None
 d['ponder']=best.split(' ponder ',1)[1] if ' ponder ' in best else None
 return d
bp.parse_search=parse
def cpu():
 values=[ctypes.c_ulonglong() for _ in range(3)]
 assert ctypes.windll.kernel32.GetSystemTimes(*(ctypes.byref(v) for v in values))
 return tuple(v.value for v in values)
def ident(a,b):
 bp.compare_identity(a,b)
 assert [(r['pv'],r['ponder']) for r in a['searches']]==[(r['pv'],r['ponder']) for r in b['searches']]
cases=bp.load_suite(bp.DEFAULT_SUITE)
result={'suite_sha256':bp.sha256(bp.DEFAULT_SUITE),'pairs':12,'node_limit':600000,'backends':{}}
for suffix in ('','-pext'):
 exes={a:out/(stem+suffix+'.exe') for a,stem in [('base','base'),('candidate','final')]}
 group={'hashes':{a:bp.sha256(p) for a,p in exes.items()},'rows':[]}
 for a,p in exes.items():
  nodes,*_=bc.run_bench(p,13,1,[]); assert nodes==7601220,(a,suffix,nodes)
  group[a+'_bench_nodes']=nodes
  bp.run_engine(p,cases,600000,1,False) # warm-up excluded
 for i in range(12):
  pair={}; row={'pair':i,'nps':{},'cpu_busy_percent':{}}
  for a in (('base','candidate') if i%2==0 else ('candidate','base')):
   before=cpu(); d=bp.run_engine(exes[a],cases,600000,1,False); after=cpu()
   idle,kernel,user=[b-a for a,b in zip(before,after)]
   row['cpu_busy_percent'][a]=100*(1-idle/(kernel+user))
   pair[a]=d
   row['nps'][a]=sum(r['reported_nodes'] for r in d['searches'])*1000/sum(r['reported_time_ms'] for r in d['searches'])
   (out/f'final{suffix}-{a}-{i}.json').write_text(json.dumps(d,indent=2))
  ident(pair['base'],pair['candidate'])
  group['rows'].append(row)
  print(suffix or 'magic',row,flush=True)
  result['backends'][suffix or 'magic']=group
  (out/'confirmation.json').write_text(json.dumps(result,indent=2))
 a=[r['nps']['base'] for r in group['rows']]; b=[r['nps']['candidate'] for r in group['rows']]
 delta=lambda x,y:100*(statistics.median(y)/statistics.median(x)-1)
 rng=random.Random(4118)
 samples=sorted(delta(rng.choices(a,k=len(a)),rng.choices(b,k=len(b))) for _ in range(5000))
 group['median_nps']={'base':statistics.median(a),'candidate':statistics.median(b)}
 group['gain_percent']=delta(a,b);group['bootstrap_95_percent']=[samples[125],samples[4874]]
 group['candidate_faster_pairs']=sum(y>x for x,y in zip(a,b))
 group['max_cpu_busy_percent']=max(v for r in group['rows'] for v in r['cpu_busy_percent'].values())
 print('RESULT',suffix, {k:v for k,v in group.items() if k!='rows'},flush=True)
 (out/'confirmation.json').write_text(json.dumps(result,indent=2))
for i in range(3):
 for arm in (('base','final') if i%2==0 else ('final','base')):
  d=subprocess.run([str((out/f'board-{arm}.exe').resolve())],capture_output=True,text=True,check=True)
  assert 'preflight: PASS' in d.stdout
  (out/f'final-board-{arm}-{i}.txt').write_text(d.stdout)
print('COMPLETE',flush=True)
