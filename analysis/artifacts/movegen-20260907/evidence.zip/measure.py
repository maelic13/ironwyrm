import sys,json,subprocess,statistics,hashlib,time
from pathlib import Path
sys.path.insert(0,str(Path('tools/diag').resolve()))
import bench_counters as bc
import board_search_profile as bp
out=Path('tools/results/movegen-411b8'); cases=bp.load_suite(bp.DEFAULT_SUITE)
for arm in ('base','cand'):
 nodes,*_=bc.run_bench(out/(arm+'.exe'),13,1,[])
 assert nodes==7601220,(arm,nodes)
 print('fingerprint',arm,nodes,flush=True)
for arm in ('base','cand'):
 r=subprocess.run([str((out/('board-'+arm+'.exe')).resolve())],text=True,capture_output=True,check=True)
 (out/(arm+'-board-screen.txt')).write_text(r.stdout)
 print(arm,[s for s in r.stdout.splitlines() if s.startswith('summary|')],flush=True)
rows=[]
for i in range(8):
 pair={}
 for arm in (('base','cand') if i%2==0 else ('cand','base')):
  d=bp.run_engine(out/(arm+'.exe'),cases,600000,1,False)
  (out/f'{arm}-search-{i}.json').write_text(json.dumps(d,indent=2))
  pair[arm]=d
 bp.compare_identity(pair['base'],pair['cand'])
 row={'pair':i}
 for arm,d in pair.items():
  row[arm]=sum(x['reported_nodes'] for x in d['searches'])*1000/sum(x['reported_time_ms'] for x in d['searches'])
 rows.append(row); (out/'screen.json').write_text(json.dumps(rows,indent=2))
 print(row,flush=True)
print('median gain %',100*(statistics.median(r['cand'] for r in rows)/statistics.median(r['base'] for r in rows)-1),flush=True)
