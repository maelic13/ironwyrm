_RNvNtNtCscX113maW9sw_5rarog5board7movegen24generate_captures_pinned:
.seh_proc _RNvNtNtCscX113maW9sw_5rarog5board7movegen24generate_captures_pinned
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$592, %rsp
	.seh_stackalloc 592
	.seh_endprologue
	movq	%rdx, %rdi
	movzbl	258(%rdx), %edx
	movl	%edx, %eax
	shll	$4, %eax
	leal	(%rax,%rax,2), %eax
	movl	$64, %r9d
	rep		bsfq	64(%rdi,%rax), %r9
	movq	%rcx, %rsi
	movq	120(%rdi,%rdx,8), %rbx
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB303_1
.LBB303_2:
	xorl	%eax, %eax
	testb	%dl, %dl
	movl	$48, %r8d
	cmovnel	%eax, %r8d
	movq	56(%rdi,%r8), %rcx
	movq	40(%rdi,%r8), %r11
	orq	%rcx, %r11
	movl	%r9d, %r10d
	andl	$63, %r10d
	orq	48(%rdi,%r8), %rcx
	movl	%r10d, %r8d
	shll	$5, %r8d
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %r14
	movq	2104(%r8,%r14), %r15
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %r12
	andq	(%r12,%r15,8), %r11
	movq	4152(%r8,%r14), %r8
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %r14
	andq	(%r14,%r8,8), %rcx
	orq	%r11, %rcx
	je	.LBB303_5
	shll	$9, %r10d
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen7BETWEEN(%rip), %r8
	addq	%r10, %r8
	movq	136(%rdi), %r10
	xorl	%r11d, %r11d
	xorl	%eax, %eax
	.p2align	4
.LBB303_4:
	movq	%rcx, %r14
	decq	%rcx
	rep		bsfq	%r14, %r15
	movq	(%r8,%r15,8), %r15
	andq	%r10, %r15
	leaq	-1(%r15), %r12
	movq	%r15, %r13
	andq	%rbx, %r13
	testq	%r12, %r15
	cmovneq	%r11, %r13
	orq	%r13, %rax
	andq	%r14, %rcx
	jne	.LBB303_4
.LBB303_5:
	movl	%edx, %r8d
	xorb	$1, %r8b
	movq	$0, 576(%rsp)
	movq	%rax, 584(%rsp)
	leaq	64(%rsp), %rbx
	movq	%rbx, 40(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rdi, %rcx
	callq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen21gen_captures_with_pin
	movl	$528, %r8d
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	callq	memcpy
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$592, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB303_1:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rax
	movq	%rax, 56(%rsp)
	leaq	56(%rsp), %rax
	movq	%rax, 64(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %rax
	leaq	64(%rsp), %r8
	movq	%rdx, %r14
	movb	$1, %dl
	movq	%r9, %r15
	movq	%rax, %r9
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	movq	%r15, %r9
	movq	%r14, %rdx
	jmp	.LBB303_2
	.seh_endproc
