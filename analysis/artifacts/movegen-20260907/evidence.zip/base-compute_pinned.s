_RNvNtNtCscX113maW9sw_5rarog5board7movegen14compute_pinned:
.seh_proc _RNvNtNtCscX113maW9sw_5rarog5board7movegen14compute_pinned
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	movq	%rcx, %rsi
	movzbl	%r8b, %eax
	movq	120(%rcx,%rax,8), %rdi
	movl	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %eax
	testl	%eax, %eax
	jne	.LBB297_1
.LBB297_2:
	movq	136(%rsi), %r10
	andb	$63, %dl
	movzbl	%dl, %edx
	movl	%edx, %eax
	shll	$5, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %r11
	movq	2096(%rax,%r11), %r8
	movq	%r8, %rbx
	andq	%r10, %rbx
	movq	2112(%rax,%r11), %r14
	imulq	%r14, %rbx
	movzbl	2120(%rax,%r11), %ecx
	shrq	%cl, %rbx
	movq	2104(%rax,%r11), %rax
	addq	%rax, %rbx
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+8(%rip), %r15
	movq	(%r15,%rbx,8), %rbx
	andq	%rdi, %rbx
	xorq	%r10, %rbx
	andq	%r8, %rbx
	imulq	%r14, %rbx
	shrq	%cl, %rbx
	addq	%rax, %rbx
	xorl	%eax, %eax
	testb	%r9b, %r9b
	movl	$6, %r9d
	cmoveq	%rax, %r9
	movq	56(%rsi,%r9,8), %r8
	movq	40(%rsi,%r9,8), %rcx
	orq	%r8, %rcx
	andq	(%r15,%rbx,8), %rcx
	je	.LBB297_7
	movl	%edx, %eax
	shll	$9, %eax
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen7BETWEEN(%rip), %rbx
	addq	%rax, %rbx
	xorl	%eax, %eax
	jmp	.LBB297_4
	.p2align	4
.LBB297_6:
	orq	%r14, %rax
	leaq	-1(%rcx), %r14
	andq	%r14, %rcx
	je	.LBB297_7
.LBB297_4:
	rep		bsfq	%rcx, %r14
	movq	(%rbx,%r14,8), %r14
	andq	%rdi, %r14
	leaq	-1(%r14), %r15
	movq	%r14, %r12
	xorq	%r15, %r12
	cmpq	%r15, %r12
	ja	.LBB297_6
	xorl	%r14d, %r14d
	jmp	.LBB297_6
.LBB297_7:
	movl	%edx, %ecx
	shll	$5, %ecx
	movq	4144(%rcx,%r11), %rbx
	movq	4152(%rcx,%r11), %r14
	movq	%rbx, %r15
	andq	%r10, %r15
	movq	4160(%rcx,%r11), %r12
	imulq	%r12, %r15
	movzbl	4168(%rcx,%r11), %ecx
	shrq	%cl, %r15
	addq	%r14, %r15
	movq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+32(%rip), %r11
	movq	(%r11,%r15,8), %r15
	andq	%rdi, %r15
	xorq	%r10, %r15
	andq	%rbx, %r15
	imulq	%r12, %r15
	shrq	%cl, %r15
	addq	%r14, %r15
	orq	48(%rsi,%r9,8), %r8
	andq	(%r11,%r15,8), %r8
	je	.LBB297_12
	shll	$9, %edx
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7movegen7BETWEEN(%rip), %rcx
	addq	%rdx, %rcx
	jmp	.LBB297_9
	.p2align	4
.LBB297_11:
	orq	%rdx, %rax
	leaq	-1(%r8), %rdx
	andq	%rdx, %r8
	je	.LBB297_12
.LBB297_9:
	rep		bsfq	%r8, %rdx
	movq	(%rcx,%rdx,8), %rdx
	andq	%rdi, %rdx
	leaq	-1(%rdx), %r9
	movq	%rdx, %r10
	xorq	%r9, %r10
	cmpq	%r9, %r10
	ja	.LBB297_11
	xorl	%edx, %edx
	jmp	.LBB297_11
.LBB297_12:
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB297_1:
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS(%rip), %rax
	movq	%rax, 48(%rsp)
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	anon.2af38a137a80de8a147d965b237c0766.2(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	_RNvNtNtCscX113maW9sw_5rarog5board7attacks7ATTACKS+6192(%rip), %rcx
	leaq	anon.2af38a137a80de8a147d965b237c0766.4(%rip), %rax
	leaq	56(%rsp), %r8
	movl	%edx, %ebx
	movb	$1, %dl
	movl	%r9d, %ebp
	movq	%rax, %r9
	callq	_RNvMs0_NtNtNtNtCslFVcyoAu48q_3std3sys4sync4once5futexNtB5_4Once4call
	movl	%ebx, %edx
	movl	%ebp, %r9d
	jmp	.LBB297_2
	.seh_endproc
