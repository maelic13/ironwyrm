import hashlib
import json
from pathlib import Path

before_path = Path(r"tools/results/v2-accepted-pgo/endgame-truth.json")
after_path = Path(r"tools/results/mopup-diag/endgame-truth.json")
before = json.loads(before_path.read_text(encoding="utf-8"))
after = json.loads(after_path.read_text(encoding="utf-8"))
for key in ("schema", "syzygy", "positions_per_family", "nodes_per_move", "max_plies", "seed", "hash_mb", "persistent_tt_per_game"):
    assert before[key] == after[key], (key, before[key], after[key])
assert set(before["families"]) == set(after["families"])
rows = []
for family in before["families"]:
    left = before["families"][family]
    right = after["families"][family]
    assert left["theoretically_won"] == right["theoretically_won"]
    left_positions = left["positions"]
    right_positions = right["positions"]
    assert len(left_positions) == len(right_positions)
    lost = []
    gained = []
    for a, b in zip(left_positions, right_positions):
        assert (a["index"], a["fen"], a["theory_wdl"], a["theory_dtz"]) == (b["index"], b["fen"], b["theory_wdl"], b["theory_dtz"])
        if a["theory_wdl"] != 2:
            continue
        a_converted = a["outcome"] == "mated"
        b_converted = b["outcome"] == "mated"
        if a_converted and not b_converted:
            lost.append({"index": a["index"], "fen": a["fen"], "before": a["outcome"], "after": b["outcome"]})
        elif b_converted and not a_converted:
            gained.append({"index": a["index"], "fen": a["fen"], "before": a["outcome"], "after": b["outcome"]})
    rows.append({
        "family": family,
        "theoretically_won": left["theoretically_won"],
        "before_converted": left["converted"],
        "after_converted": right["converted"],
        "delta": right["converted"] - left["converted"],
        "gained": gained,
        "lost": lost,
    })
output = {
    "schema": "rarog-mate-drive-promotion-closure-v1",
    "before": {"path": str(before_path), "sha256": hashlib.sha256(before_path.read_bytes()).hexdigest()},
    "after": {"path": str(after_path), "sha256": hashlib.sha256(after_path.read_bytes()).hexdigest()},
    "families": rows,
}
Path(r"D:/chess/results/4119-promotion-closure-matrix.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
for row in rows:
    if row["delta"] or row["gained"] or row["lost"]:
        print(f'{row["family"]}: {row["before_converted"]}/{row["theoretically_won"]} -> {row["after_converted"]}/{row["theoretically_won"]}; gained={len(row["gained"])} lost={len(row["lost"])}')
