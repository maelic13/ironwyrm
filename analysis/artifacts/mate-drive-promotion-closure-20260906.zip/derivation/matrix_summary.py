import json
from pathlib import Path
matrix = json.loads(Path(r"D:/chess/results/4119-promotion-closure-matrix.json").read_text())
before = json.loads(Path(r"tools/results/v2-accepted-pgo/endgame-truth.json").read_text())
after = json.loads(Path(r"tools/results/mopup-diag/endgame-truth.json").read_text())
rows = {row["family"]: row for row in matrix["families"]}
print("family,before,after,net,gained,lost,changed_positions")
for family in before["families"]:
    left = before["families"][family]
    right = after["families"][family]
    changed_positions = sum(a != b for a, b in zip(left["positions"], right["positions"]))
    if not changed_positions:
        continue
    row = rows[family]
    print(
        f'{family},{left["converted"]}/{left["theoretically_won"]},'
        f'{right["converted"]}/{right["theoretically_won"]},'
        f'{row["delta"]},{len(row["gained"])},{len(row["lost"])},{changed_positions}'
    )
