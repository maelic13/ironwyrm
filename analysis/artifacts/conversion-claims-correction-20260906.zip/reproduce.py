from pathlib import Path
import json

root = Path(__file__).resolve().parent
paths = {
    'pre100': root/'reports/pre-e08-v2-100.json',
    'e08100': root/'reports/e08-v2-100.json',
    'e12100': root/'reports/e12-v2-100.json',
    'pre400': root/'reports/pre-e08-v2-400-focus.json',
    'e08400': root/'reports/e08-v2-400-focus.json',
}
data = {k: json.loads(v.read_text(encoding='utf-8')) for k, v in paths.items()}

def compare(left, right):
    a, b = data[left], data[right]
    for key in ('schema', 'syzygy', 'positions_per_family', 'nodes_per_move', 'max_plies', 'seed', 'hash_mb', 'persistent_tt_per_game'):
        assert a[key] == b[key], (left, right, key)
    assert a['cohort']['sha256'] == b['cohort']['sha256'], (left, right, 'cohort')
    assert set(a['families']) == set(b['families']), (left, right, 'families')
    for family in a['families']:
        ap, bp = a['families'][family]['positions'], b['families'][family]['positions']
        assert [(x['index'], x['fen'], x['theory_wdl'], x['theory_dtz']) for x in ap] == [(x['index'], x['fen'], x['theory_wdl'], x['theory_dtz']) for x in bp], (left, right, family)

def total(name):
    fam = data[name]['families'].values()
    return sum(x['converted'] for x in fam), sum(x['theoretically_won'] for x in fam)

def pair(left, right, families=None):
    both = left_only = right_only = neither = 0
    names = families or data[left]['families'].keys()
    for family in names:
        for a, b in zip(data[left]['families'][family]['positions'], data[right]['families'][family]['positions']):
            if a['theory_wdl'] != 2:
                continue
            x, y = a['outcome'] == 'mated', b['outcome'] == 'mated'
            if x and y: both += 1
            elif x: left_only += 1
            elif y: right_only += 1
            else: neither += 1
    return both, left_only, right_only, neither

compare('pre100', 'e08100')
compare('e08100', 'e12100')
compare('pre400', 'e08400')
assert all(d['schema'] == 'rarog-endgame-truth-v2' for d in data.values())
for left, right, label in [('pre100', 'e08100', 'RAR-E08'), ('e08100', 'e12100', 'RAR-E12')]:
    a, n = total(left); b, _ = total(right)
    print(f'{label}: {a}/{n} -> {b}/{n}; paired={pair(left, right)}')
for family in data['pre400']['families']:
    a = data['pre400']['families'][family]
    b = data['e08400']['families'][family]
    print(f'{family}: {a["converted"]}/{a["theoretically_won"]} -> {b["converted"]}/{b["theoretically_won"]}; paired={pair("pre400", "e08400", [family])}')
print('contract: PASS')
