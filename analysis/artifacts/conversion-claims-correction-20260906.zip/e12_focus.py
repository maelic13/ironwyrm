import json
from pathlib import Path
p={
'e08':Path(r'D:/code/rarog/tools/results/truth-v2-e08/endgame-truth.json'),
'e12':Path(r'D:/chess/results/41110-corrected-claims/e12-v2-100/endgame-truth.json')}
d={k:json.loads(v.read_text()) for k,v in p.items()}
for fam in ('KP-K','KQ-K','KQ-KP','KBN-K'):
 print(fam)
 for arm in ('e08','e12'):
  x=d[arm]['families'][fam]
  print(arm, 'conversion',f'{x["converted"]}/{x["theoretically_won"]}', 'dtz',f'{x["dtz_progress_moves"]}/{x["dtz_checked_moves"]}={x["dtz_progress_rate"]:.4f}')
