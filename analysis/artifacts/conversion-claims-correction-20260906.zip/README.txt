RAR-M24 archived inputs

All reports use rarog-endgame-truth-v2, 60,000 nodes/move, 100-ply limit,
seed 6200600, 16 MB hash, 30 one-thread workers, Syzygy 3-6, and per-position
records. The derivation script asserts matching schema, cohort, condition
fields, family set, FEN/index and Syzygy truth before it differences a pair.

pre-e08-v2-100: RAR-E08 baseline binary, 19 x 100 cohort.
e08-v2-100: accepted RAR-E08 head from truth-v2 baseline, 19 x 100 cohort.
e12-v2-100: RAR-E12 candidate binary (e09cand artifact), 19 x 100 cohort.
pre/e08-v2-400-focus: RAR-E08 baseline/head over original four focus families,
400 positions/family.
