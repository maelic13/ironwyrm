import hashlib
import json
from pathlib import Path

root = Path(r'D:/chess/results/41110-corrected-claims')
inputs = {
    'pre100': root/'pre-e08-v2-100'/'endgame-truth.json',
    'e08100': Path(r'D:/code/rarog/tools/results/truth-v2-e08/endgame-truth.json'),
    'e12100': root/'e12-v2-100'/'endgame-truth.json',
    'pre400': root/'pre-e08-v2-400-focus'/'endgame-truth.json',
    'e08400': root/'e08-v2-400-focus'/'endgame-truth.json',
}
data={k:json.loads(p.read_text(encoding='utf-8')) for k,p in inputs.items()}

def assert_match(left, right):
    a,b=data[left],data[right]
    for key in ('schema','syzygy','positions_per_family','nodes_per_move','max_plies','seed','hash_mb','persistent_tt_per_game'):
        assert a[key] == b[key], (left,right,key,a[key],b[key])
    assert a['cohort']['sha256'] == b['cohort']['sha256'], (left,right)
    assert set(a['families']) == set(b['families']), (left,right)
    for name in a['families']:
        ap,bp=a['families'][name]['positions'],b['families'][name]['positions']
        assert [(p['index'],p['fen'],p['theory_wdl'],p['theory_dtz']) for p in ap] == [(p['index'],p['fen'],p['theory_wdl'],p['theory_dtz']) for p in bp], (left,right,name)

def total(key):
    d=data[key]
    return sum(x['converted'] for x in d['families'].values()), sum(x['theoretically_won'] for x in d['families'].values())

def pairs(left,right,family=None):
    names=[family] if family else data[left]['families']
    aa=bb=ab=ba=0
    for name in names:
        for p,q in zip(data[left]['families'][name]['positions'],data[right]['families'][name]['positions']):
            if p['theory_wdl'] != 2: continue
            x=p['outcome']=='mated'; y=q['outcome']=='mated'
            if x and y: aa+=1
            elif x: ab+=1
            elif y: ba+=1
            else: bb+=1
    return aa,ab,ba,bb

assert_match('pre100','e08100')
assert_match('e08100','e12100')
assert_match('pre400','e08400')
for key in inputs:
    assert data[key]['schema'] == 'rarog-endgame-truth-v2'

lines=[]
lines.append('4.11.10 derivation — RAR-M24')
lines.append('')
lines.append('All contract assertions passed: v2 schema, fixed cohort, seed, budget, hash, families, FEN/index and Syzygy truth match within each paired comparison.')
for key in ('pre100','e08100','e12100','pre400','e08400'):
    c,n=total(key)
    lines.append(f'{key}: {c}/{n} = {c/n:.4f}; sha256={hashlib.sha256(inputs[key].read_bytes()).hexdigest().upper()}')
lines.append('')
for left,right,label in [('pre100','e08100','RAR-E08 full 100'),('e08100','e12100','RAR-E12 full 100')]:
    c0,n=total(left); c1,_=total(right)
    both,left_only,right_only,neither=pairs(left,right)
    lines.append(f'{label}: {c0}/{n} -> {c1}/{n} ({(c1-c0)/n:+.4f}); paired both/left-only/right-only/neither = {both}/{left_only}/{right_only}/{neither}')
lines.append('')
lines.append('RAR-E08 corrected 400-focus conversion:')
for fam in data['pre400']['families']:
    a=data['pre400']['families'][fam]; b=data['e08400']['families'][fam]
    both,left_only,right_only,neither=pairs('pre400','e08400',fam)
    lines.append(f'{fam}: {a["converted"]}/{a["theoretically_won"]} -> {b["converted"]}/{b["theoretically_won"]} ({(b["converted"]-a["converted"])/a["theoretically_won"]:+.4f}); paired both/pre-only/e08-only/neither = {both}/{left_only}/{right_only}/{neither}')
output=root/'derivation.txt'
output.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(output.read_text(encoding='utf-8'))
